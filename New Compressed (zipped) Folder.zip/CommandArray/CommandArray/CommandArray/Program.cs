﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FinchAPI;

namespace CommandArray
{


    /* **************************
    
        Title: Command Array
        Application Type: Console
        Author: Sebastian Maddix
        Date Created:  3-20-19
        Last Modified: 3-24-19

       **************************    
   */
    public enum FinchCommand
    {   
        DONE,
        MOVEFORWARD,
        MOVEBACKWARD,
        STOPMOTORS,
        DELAY,
        TURNRIGHT,
        TURNLEFT,
        LEDON,
        LEDOFF
    }

    class Program
    {

        static void Main(string[] args)
        {   

            Finch myFinch = new Finch();

            DisplayOpeningScreen();

            DisplayInitializeFinch(myFinch);

            DisplayMainMenu(myFinch);

            DisplayClosingScreen(myFinch);

        }
        static void DisplayMainMenu(Finch myFinch)
        {
            string menuChoice;

            bool loopRunning = true;

            FinchCommand userCommand;
            int delayDuration = 0;
            int numberOfCommands = 0;
            int motorSpeed = 0;
            int LEDBrightness = 0;
            //



            FinchCommand[] commands = new FinchCommand[8];

            commands[0] = FinchCommand.DONE;
            commands[1] = FinchCommand.MOVEFORWARD;
            commands[2] = FinchCommand.MOVEBACKWARD;
            commands[3] = FinchCommand.STOPMOTORS;
            commands[4] = FinchCommand.TURNRIGHT;
            commands[5] = FinchCommand.TURNLEFT;
            commands[6] = FinchCommand.LEDON;
            commands[7] = FinchCommand.LEDOFF;


            while (loopRunning)
            {
                Console.Clear();
                Console.WriteLine();
                Console.WriteLine("Main Menu");
                Console.WriteLine();

                Console.WriteLine("\t1 Get Command Parameters)");
                Console.WriteLine("\t2) Get Finch Commands");
                Console.WriteLine("\t3) Execute Commands");
                Console.WriteLine("\tE) Exit");
                Console.WriteLine();
                Console.Write("Enter Choice:");
                menuChoice = Console.ReadLine();

                switch (menuChoice)
                {
                    case "1":
                        numberOfCommands = DisplayGetNumberOfCommands();
                        delayDuration = DisplayGetDelayDuration();
                        motorSpeed = DisplayGetMotorSpeed();
                        LEDBrightness = DisplayGetLEDBrightness();
                        break;
            
                    case "2":
                        DisplayGetCommands(numberOfCommands);
                        //cannot figure out the error for this - will be asking after class to see what I was missing
                        break;

                    case "3":

                        break;

                    case "e":
                    case "E":
                        
                        loopRunning = false;
                        break;

                    default:
                        break;
                }
            }
        }

        static void DisplayGetCommands(int numberOfCommands, string commands, string userCommand)
        {   string userResponse;
            DisplayHeader("Enter Command");
            Console.WriteLine("0] Done");
            Console.WriteLine("1] ");
            Console.WriteLine("2] ");
            Console.WriteLine("3] ");
            Console.WriteLine("4] ");
            Console.WriteLine("5] ");
            Console.WriteLine("6] ");
            Console.WriteLine("7] ");
            Console.WriteLine("8] ");

            //Console.ReadLine(string userResponse, out int FinchCommand);    

            foreach (FinchCommand command in commands)
            {
                userResponse = Console.ReadLine();

                Enum.TryParse(userResponse, out userCommand);
                Console.WriteLine();
                Console.WriteLine();
            }


        }
       

        private static void ExecuteOrder66()
        {

        }

        static int DisplayGetLEDBrightness()
        {

            int ledBrightness;
            string userResponse;

            DisplayHeader("LED Brightness");

            Console.Write("Enter LED Brightness [0-255]");
            userResponse = Console.ReadLine();

            ledBrightness = int.Parse(userResponse);

            return ledBrightness;
        }

        static int DisplayGetMotorSpeed()
        {

            int motorSpeed;
            string userResponse;

            DisplayHeader("Motor Speed [0 - 255]");

            Console.Write("Enter MotorSpeed:");
            userResponse = Console.ReadLine();

            motorSpeed = int.Parse(userResponse);

            return motorSpeed;
        }

        static int DisplayGetDelayDuration()
        { 

            int delayDuration;
            string userResponse;

            DisplayHeader("Delay Duration");

            Console.Write("Enter Delay Duration:");
            userResponse = Console.ReadLine();

            delayDuration = int.Parse(userResponse);

            return delayDuration;
        }

        static int DisplayGetNumberOfCommands()
        {
            int numberOfCommands;
            string userResponse;

            DisplayHeader("Number of Commands");

            Console.Write("Enter the number of commands:");
            userResponse =  Console.ReadLine();

            numberOfCommands = int.Parse(userResponse);

            return numberOfCommands;
        }

        static void DisplayInitializeFinch(Finch myFinch)
        {
            DisplayHeader("Initialize the Finch");

            Console.WriteLine("Please plug your Finch Robot into the computer.");
            Console.WriteLine();
            DisplayContinuePrompt();

            while (!myFinch.connect())
            {
                Console.WriteLine("Please confirm the Finch Robot is connect");
                DisplayContinuePrompt();
            }

            FinchConnectedAlert(myFinch);
            Console.WriteLine("Your Finch Robot is now connected");

            DisplayContinuePrompt();
        }

        static void FinchConnectedAlert(Finch myFinch)
        {
            myFinch.setLED(0, 255, 0);

            for (int frequency = 17000; frequency > 100; frequency -= 100)
            {
                myFinch.noteOn(frequency);
                myFinch.wait(10);
            }
            
            myFinch.noteOff();
        }

        static void DisplayOpeningScreen()
        {
            Console.WriteLine();
            Console.WriteLine("\tProgram Your Finch");
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        static void DisplayClosingScreen(Finch myFinch)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\tThank You!");
            Console.WriteLine();

            myFinch.disConnect();

            DisplayContinuePrompt();
        }

        #region HELPER METHODS
        static void DisplayContinuePrompt()
        {
            Console.WriteLine();
            Console.WriteLine("Press any key to continue.");
            Console.ReadKey();
        }
        static void DisplayHeader(string header)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("\t\t" + header);
            Console.WriteLine();
        }
        #endregion

    }
}
